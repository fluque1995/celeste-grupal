import plotly.offline as py
import plotly.graph_objs as go
from planet import Planet


class SolarSystem:

    def __init__(self):
        self.inner_planets = [
            Planet("Mercurio", 0.206, 0.387, 87.97),
            Planet("Venus", 0.007, 0.723, 224.7),
            Planet("La tierra", 0.017, 1, 365.26),
            Planet("Marte", 0.093, 1.524, 686.98)
        ]

        self.outer_planets = {
            "Júpiter": Planet("Júpiter", 0.048, 5.203, 4332.6),
            "Saturno": Planet("Saturno", 0.056, 9.546, 10759),
            "Urano": Planet("Urano", 0.047, 19.2, 30687),
            "Neptuno": Planet("Neptuno", 0.009, 30.09, 60784)
        }

    def display_inner_planets(self):

        orbits = [planet.get_orbit(100) for planet in self.inner_planets]
        planets = [[planet.position(i) for i in range(0, 690, 10)]
                   for planet in self.inner_planets]

        rng = int(1.2*self.inner_planets[-1].a) + 1

        layout = dict(
            width=600, height=500,
            xaxis=dict(range=[-rng, rng],
                       autorange=False,
                       zeroline=False),
            yaxis=dict(range=[-rng, rng],
                       autorange=False,
                       zeroline=False),
            title='Movimiento orbital de los planetas interiores',
            hovermode='closest',
            updatemenus=[
                {
                    'type': 'buttons',
                    'buttons': [
                        {
                            'label': 'Play',
                            'method': 'animate',
                            'args': [None]
                        }
                    ]
                }
            ]
        )
        data = [
            dict(x=[0], y=[0],
                 mode='markers',
                 marker=dict(
                     size=20,
                     color='rgba(230, 230, 0, .9)',
                     line=dict(width=1, color='rgb(100,100,0)')
                 ),
                 name='Sol'),
            dict(x=orbits[0][:, 0],
                 y=orbits[0][:, 1],
                 mode='lines',
                 line=dict(width=2, color='blue'),
                 name="Órbita de Mercurio"),
            dict(x=orbits[1][:, 0],
                 y=orbits[1][:, 1],
                 mode='lines',
                 line=dict(width=2, color='orange'),
                 name="Órbita de Venus"),
            dict(x=orbits[2][:, 0],
                 y=orbits[2][:, 1],
                 mode='lines',
                 line=dict(width=2, color='red'),
                 name="Órbita de La Tierra"),
            dict(x=orbits[3][:, 0],
                 y=orbits[3][:, 1],
                 mode='lines',
                 line=dict(width=2, color='green'),
                 name="Órbita de Marte"),
            dict(x=[planets[0][0][0]],
                 y=[planets[0][0][1]],
                 mode='markers',
                 marker=dict(
                     size=15,
                     color='rgba(152, 0, 0, .8)',
                     line=dict(
                         width=2,
                         color='rgb(0, 0, 0)')),
                 name="Mercurio: día 0"),
            dict(x=[planets[1][0][0]],
                 y=[planets[1][0][1]],
                 mode='markers',
                 marker=dict(
                     size=15,
                     color='rgba(152, 0, 0, .8)',
                     line=dict(
                         width=2,
                         color='rgb(0, 0, 0)')),
                 name="Venus: día 0"),
            dict(x=[planets[2][0][0]],
                 y=[planets[2][0][1]],
                 mode='markers',
                 marker=dict(
                     size=15,
                     color='rgba(152, 0, 0, .8)',
                     line=dict(
                         width=2,
                         color='rgb(0, 0, 0)')),
                 name="La Tierra: día 0"),
            dict(x=[planets[3][0][0]],
                 y=[planets[3][0][1]],
                 mode='markers',
                 marker=dict(
                     size=15,
                     color='rgba(152, 0, 0, .8)',
                     line=dict(
                         width=2,
                         color='rgb(0, 0, 0)')),
                 name="Marte: día 0")
        ]
        frames = [
            dict(data=[
                dict(x=[0], y=[0],
                     mode='markers',
                     marker=dict(
                         size=20,
                         color='rgba(230, 230, 0, .9)',
                         line=dict(width=1, color='rgb(100,100,0)')
                     ),
                     name='Sol'),
                dict(x=orbits[0][:, 0],
                     y=orbits[0][:, 1],
                     mode='lines',
                     line=dict(width=2, color='blue'),
                     name="Órbita de Mercurio"),
                dict(x=orbits[1][:, 0],
                     y=orbits[1][:, 1],
                     mode='lines',
                     line=dict(width=2, color='orange'),
                     name="Órbita de Venus"),
                dict(x=orbits[2][:, 0],
                     y=orbits[2][:, 1],
                     mode='lines',
                     line=dict(width=2, color='red'),
                     name="Órbita de La Tierra"),
                dict(x=orbits[3][:, 0],
                     y=orbits[3][:, 1],
                     mode='lines',
                     line=dict(width=2, color='green'),
                     name="Órbita de Marte"),
                dict(x=[planets[0][i][0]],
                     y=[planets[0][i][1]],
                     mode='markers',
                     marker=dict(
                         size=15,
                         color='rgba(152, 0, 0, .8)',
                         line=dict(
                             width=2,
                             color='rgb(0, 0, 0)')),
                     name="Mercurio: día {}".format(10*i)),
                dict(x=[planets[1][i][0]],
                     y=[planets[1][i][1]],
                     mode='markers',
                     marker=dict(
                         size=15,
                         color='rgba(152, 0, 0, .8)',
                         line=dict(
                             width=2,
                             color='rgb(0, 0, 0)')),
                     name="Venus: día {}".format(10*i)),
                dict(x=[planets[2][i][0]],
                     y=[planets[2][i][1]],
                     mode='markers',
                     marker=dict(
                         size=15,
                         color='rgba(152, 0, 0, .8)',
                         line=dict(
                             width=2,
                             color='rgb(0, 0, 0)')),
                     name="La Tierra: día {}".format(10*i)),
                dict(x=[planets[3][i][0]],
                     y=[planets[3][i][1]],
                     mode='markers',
                     marker=dict(
                         size=15,
                         color='rgba(152, 0, 0, .8)',
                         line=dict(
                             width=2,
                             color='rgb(0, 0, 0)')),
                     name="Marte: día {}".format(10*i)),
                ]) for i in range(69)]

        fig = dict(data=data, layout=layout, frames=frames)
        py.iplot(fig, filename='plots/inner_planets_plot')


class Displayer:

    def compare_eccentric_anomalies(self, planet, time):
        print("Anomalía excéntrica de {} el día {},"
              .format(planet.name, time) +
              "calculada usando funciones de Bessel: {}"
              .format(planet.eccentric_annomaly_bessel(time, 20)))

        print("Anomalía excéntrica de {} el día {},"
              .format(planet.name, time) +
              "calculada por el método de Newton: {}"
              .format(planet.eccentric_annomaly(time)))

        print("Diferencia entre ambos valores: {}"
              .format(abs(planet.eccentric_annomaly_bessel(time, 20) -
                          planet.eccentric_annomaly(time))))

    def print_information(self, planet, time):

        print("Posición de {} en el día {}: {}"
              .format(planet.name, time, planet.position(time)))

        print("Distancia al sol de {} en el día {}: {}\n"
              .format(planet.name, time, planet.distance_to_sun(time)))

        print("Velocidad de {} en el día {}: {}"
              .format(planet.name, time, planet.speed(time)))

        print("Módulo de la velocidad de {} en el día {}: {}\n"
              .format(planet.name, time, planet.speed_module(time)))

        print("Anomalía real de {} en el día {}: {}"
              .format(planet.name, time, planet.real_annomaly(time)))

        print("Anomalía real de {} en el día {}"
              .format(planet.name, time) +
              " (cálculo a partir de la anomalía excéntrica): {}\n"
              .format(planet.real_annomaly_from_eccentric(time)))

        print("Energía de {} en el día {}: {}"
              .format(planet.name, time, planet.energy_from_time(time)))

        print("Energía (constante) de {}: {}\n"
              .format(planet.name, planet.energy()))

        print("Módulo del momento angular de {} en el día {}: {}"
              .format(planet.name, time,
                      planet.angular_moment_from_time(time)))

        print("Módulo del momento angular de {} (constante): {}\n"
              .format(planet.name, planet.c))

        self.compare_eccentric_anomalies(planet, time)

    def display_orbit(self, planet, time):

        xs = planet.get_orbit(200)

        orbit = go.Scattergl(x=xs[:, 0], y=xs[:, 1],
                             name='órbita')

        position = planet.position(time)
        planet_pos = go.Scattergl(x=[position[0]], y=[position[1]],
                                  mode='markers',
                                  marker=dict(
                                      size=15,
                                      color='rgba(152, 0, 0, .8)',
                                      line=dict(
                                          width=2,
                                          color='rgb(0, 0, 0)'
                                      )
                                  ),
                                  name='{}: día {}'
                                  .format(planet.name, time))

        sun = go.Scattergl(x=[0], y=[0],
                           mode='markers',
                           marker=dict(
                               size=20,
                               color='rgba(230, 230, 0, .9)',
                               line=dict(width=1, color='rgb(100,100,0)')
                           ),
                           name='Sol')

        rng = int(1.2*planet.a) + 1

        layout = go.Layout(
            width=600, height=500,
            xaxis=dict(
                anchor='y',
                range=[-rng, rng]
            ),
            yaxis=dict(
                anchor='x',
                autorange=False,
                range=[-rng, rng],
            )
        )
        data = [orbit, planet_pos, sun]
        fig = go.Figure(data=data, layout=layout)
        py.iplot(fig, filename='plots/orbit_plot')
